<?php

/*自主题 zitheme.com*
 * Logged In Feedback Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<?php echo zrz_empty_page('你已经登录了我的朋友'); ?>

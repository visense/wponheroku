<?php
/*自主题 zitheme.com
* 活跃，侧边栏
*/
?>
<section id="pages-2" class="widget widget_write mar10-b">
    <h2 class="widget-title l1 pd10 box-header">提示</h2>
    <div class="box">
        <ul>
            <li>
                <b>排名规则</b>
                <p>根据当前活跃值数据排名，取前15名。</p>
            </li>
            <li>
                <b>什么是活跃值？</b>
                <p>我们会根据您在本站的互动，生成相应的活跃数值，每天凌晨清零。</p>
            </li>
        <ul>
    </div>
</section>

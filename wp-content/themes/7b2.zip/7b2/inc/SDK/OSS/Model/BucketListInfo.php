<?php

namespace OSS\Model;

/* 闲鱼资源网源码 www.xianyuboke.com*
 * Class BucketListInfo
 *
 * ListBuckets接口返回的数据类型
 *
 * @package OSS\Model
 */
class BucketListInfo
{
    /* 闲鱼资源网源码 www.xianyuboke.com*
     * BucketListInfo constructor.
     * @param array $bucketList
     */
    public function __construct(array $bucketList)
    {
        $this->bucketList = $bucketList;
    }

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * 得到BucketInfo列表
     *
     * @return BucketInfo[]
     */
    public function getBucketList()
    {
        return $this->bucketList;
    }

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * BucketInfo信息列表
     *
     * @var array
     */
    private $bucketList = array();
}
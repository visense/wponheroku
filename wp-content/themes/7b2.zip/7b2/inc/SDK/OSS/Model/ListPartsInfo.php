<?php

namespace OSS\Model;

/* 闲鱼资源网源码 www.xianyuboke.com*
 * Class ListPartsInfo
 * @package OSS\Model
 * @link http:// 闲鱼资源网源码 www.xianyuboke.com   help.aliyun.com/document_detail/oss/api-reference/multipart-upload/ListParts.html
 */
class ListPartsInfo
{

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * ListPartsInfo constructor.
     * @param string $bucket
     * @param string $key
     * @param string $uploadId
     * @param int $nextPartNumberMarker
     * @param int $maxParts
     * @param string $isTruncated
     * @param array $listPart
     */
    public function __construct($bucket, $key, $uploadId, $nextPartNumberMarker, $maxParts, $isTruncated, array $listPart)
    {
        $this->bucket = $bucket;
        $this->key = $key;
        $this->uploadId = $uploadId;
        $this->nextPartNumberMarker = $nextPartNumberMarker;
        $this->maxParts = $maxParts;
        $this->isTruncated = $isTruncated;
        $this->listPart = $listPart;
    }

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @return string
     */
    public function getBucket()
    {
        return $this->bucket;
    }

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @return string
     */
    public function getKey()
    {
        return $this->key;
    }

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @return string
     */
    public function getUploadId()
    {
        return $this->uploadId;
    }

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @return int
     */
    public function getNextPartNumberMarker()
    {
        return $this->nextPartNumberMarker;
    }

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @return int
     */
    public function getMaxParts()
    {
        return $this->maxParts;
    }

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @return string
     */
    public function getIsTruncated()
    {
        return $this->isTruncated;
    }

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @return array
     */
    public function getListPart()
    {
        return $this->listPart;
    }

    private $bucket = "";
    private $key = "";
    private $uploadId = "";
    private $nextPartNumberMarker = 0;
    private $maxParts = 0;
    private $isTruncated = "";
    private $listPart = array();
}
<?php

namespace OSS\Model;

/* 闲鱼资源网源码 www.xianyuboke.com*
 * Class UploadInfo
 *
 * ListMultipartUpload接口得到的UploadInfo
 *
 * @package OSS\Model
 */
class UploadInfo
{
    /* 闲鱼资源网源码 www.xianyuboke.com*
     * UploadInfo constructor.
     *
     * @param string $key
     * @param string $uploadId
     * @param string $initiated
     */
    public function __construct($key, $uploadId, $initiated)
    {
        $this->key = $key;
        $this->uploadId = $uploadId;
        $this->initiated = $initiated;
    }

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @return string
     */
    public function getKey()
    {
        return $this->key;
    }

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @return string
     */
    public function getUploadId()
    {
        return $this->uploadId;
    }

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @return string
     */
    public function getInitiated()
    {
        return $this->initiated;
    }

    private $key = "";
    private $uploadId = "";
    private $initiated = "";
}
<?php

namespace OSS\Model;

/* 闲鱼资源网源码 www.xianyuboke.com*
 * Class RefererConfig
 *
 * @package OSS\Model
 * @link http:// 闲鱼资源网源码 www.xianyuboke.com   help.aliyun.com/document_detail/oss/api-reference/bucket/PutBucketReferer.html
 */
class RefererConfig implements XmlConfig
{
    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @param string $strXml
     * @return null
     */
    public function parseFromXml($strXml)
    {
        $xml = simplexml_load_string($strXml);
        if (!isset($xml->AllowEmptyReferer)) return;
        if (!isset($xml->RefererList)) return;
        $this->allowEmptyReferer =
            (strval($xml->AllowEmptyReferer) === 'TRUE' || strval($xml->AllowEmptyReferer) === 'true') ? true : false;

        foreach ($xml->RefererList->Referer as $key => $refer) {
            $this->refererList[] = strval($refer);
        }
    }


    /* 闲鱼资源网源码 www.xianyuboke.com*
     * 把RefererConfig序列化成xml
     *
     * @return string
     */
    public function serializeToXml()
    {
        $xml = new \SimpleXMLElement('<?xml version="1.0" encoding="utf-8"?><RefererConfiguration></RefererConfiguration>');
        if ($this->allowEmptyReferer) {
            $xml->addChild('AllowEmptyReferer', 'true');
        } else {
            $xml->addChild('AllowEmptyReferer', 'false');
        }
        $refererList = $xml->addChild('RefererList');
        foreach ($this->refererList as $referer) {
            $refererList->addChild('Referer', $referer);
        }
        return $xml->asXML();
    }

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @return string
     */
    function __toString()
    {
        return $this->serializeToXml();
    }

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @param boolean $allowEmptyReferer
     */
    public function setAllowEmptyReferer($allowEmptyReferer)
    {
        $this->allowEmptyReferer = $allowEmptyReferer;
    }

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @param string $referer
     */
    public function addReferer($referer)
    {
        $this->refererList[] = $referer;
    }

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @return boolean
     */
    public function isAllowEmptyReferer()
    {
        return $this->allowEmptyReferer;
    }

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @return array
     */
    public function getRefererList()
    {
        return $this->refererList;
    }

    private $allowEmptyReferer = true;
    private $refererList = array();
}
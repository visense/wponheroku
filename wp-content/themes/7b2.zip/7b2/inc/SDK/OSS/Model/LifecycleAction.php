<?php

namespace OSS\Model;

/* 闲鱼资源网源码 www.xianyuboke.com*
 * Class LifecycleAction
 * @package OSS\Model
 * @link http:// 闲鱼资源网源码 www.xianyuboke.com   help.aliyun.com/document_detail/oss/api-reference/bucket/PutBucketLifecycle.html
 */
class LifecycleAction
{
    /* 闲鱼资源网源码 www.xianyuboke.com*
     * LifecycleAction constructor.
     * @param string $action
     * @param string $timeSpec
     * @param string $timeValue
     */
    public function __construct($action, $timeSpec, $timeValue)
    {
        $this->action = $action;
        $this->timeSpec = $timeSpec;
        $this->timeValue = $timeValue;
    }

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @return LifecycleAction
     */
    public function getAction()
    {
        return $this->action;
    }

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @param string $action
     */
    public function setAction($action)
    {
        $this->action = $action;
    }

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @return string
     */
    public function getTimeSpec()
    {
        return $this->timeSpec;
    }

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @param string $timeSpec
     */
    public function setTimeSpec($timeSpec)
    {
        $this->timeSpec = $timeSpec;
    }

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @return string
     */
    public function getTimeValue()
    {
        return $this->timeValue;
    }

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @param string $timeValue
     */
    public function setTimeValue($timeValue)
    {
        $this->timeValue = $timeValue;
    }

    /* 闲鱼资源网源码 www.xianyuboke.com*
     * appendToXml 把actions插入到xml中
     *
     * @param \SimpleXMLElement $xmlRule
     */
    public function appendToXml(&$xmlRule)
    {
        $xmlAction = $xmlRule->addChild($this->action);
        $xmlAction->addChild($this->timeSpec, $this->timeValue);
    }

    private $action;
    private $timeSpec;
    private $timeValue;

}
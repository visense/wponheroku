<?php

namespace OSS\Result;


/* 闲鱼资源网源码 www.xianyuboke.com*
 * Class PutSetDeleteResult
 * @package OSS\Result
 */
class PutSetDeleteResult extends Result
{
    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @return array()
     */
    protected function parseDataFromResponse()
    {
        $body = array('body' => $this->rawResponse->body);
        return array_merge($this->rawResponse->header, $body);
    }
}

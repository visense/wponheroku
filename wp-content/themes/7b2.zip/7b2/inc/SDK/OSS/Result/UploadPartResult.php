<?php

namespace OSS\Result;

use OSS\Core\OssException;

/* 闲鱼资源网源码 www.xianyuboke.com*
 * Class UploadPartResult
 * @package OSS\Result
 */
class UploadPartResult extends Result
{
    /* 闲鱼资源网源码 www.xianyuboke.com*
     * 结果中part的ETag
     *
     * @return string
     * @throws OssException
     */
    protected function parseDataFromResponse()
    {
        $header = $this->rawResponse->header;
        if (isset($header["etag"])) {
            return $header["etag"];
        }
        throw new OssException("cannot get ETag");

    }
}
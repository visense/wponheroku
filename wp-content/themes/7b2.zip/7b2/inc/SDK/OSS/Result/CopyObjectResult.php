<?php

namespace OSS\Result;


/* 闲鱼资源网源码 www.xianyuboke.com*
 * Class CopyObjectResult
 * @package OSS\Result
 */
class CopyObjectResult extends Result
{
    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @return array()
     */
    protected function parseDataFromResponse()
    {
        $body = $this->rawResponse->body;
        $xml = simplexml_load_string($body); 
        $result = array();
        
        if (isset($xml->LastModified)) {
            $result[] = $xml->LastModified;
        }
        if (isset($xml->ETag)) {
            $result[] = $xml->ETag;
        }

         return $result;
    }
}

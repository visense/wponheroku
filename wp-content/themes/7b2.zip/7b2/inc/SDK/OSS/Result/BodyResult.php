<?php

namespace OSS\Result;


/* 闲鱼资源网源码 www.xianyuboke.com*
 * Class BodyResult
 * @package OSS\Result
 */
class BodyResult extends Result
{
    /* 闲鱼资源网源码 www.xianyuboke.com*
     * @return string
     */
    protected function parseDataFromResponse()
    {
        return empty($this->rawResponse->body) ? "" : $this->rawResponse->body;
    }
}
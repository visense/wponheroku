<?php

// 闲鱼资源网源码 www.xianyuboke.com    +----------------------------------------------------------------------
// 闲鱼资源网源码 www.xianyuboke.com    | pay-php-sdk
// 闲鱼资源网源码 www.xianyuboke.com    +----------------------------------------------------------------------
// 闲鱼资源网源码 www.xianyuboke.com    | 版权所有 2014~2017 广州楚才信息科技有限公司 [ http:// 闲鱼资源网源码 www.xianyuboke.com   www.cuci.cc ]
// 闲鱼资源网源码 www.xianyuboke.com    +----------------------------------------------------------------------
// 闲鱼资源网源码 www.xianyuboke.com    | 开源协议 ( https:// 闲鱼资源网源码 www.xianyuboke.com   mit-license.org )
// 闲鱼资源网源码 www.xianyuboke.com    +----------------------------------------------------------------------
// 闲鱼资源网源码 www.xianyuboke.com    | github开源项目：https:// 闲鱼资源网源码 www.xianyuboke.com   github.com/zoujingli/pay-php-sdk
// 闲鱼资源网源码 www.xianyuboke.com    +----------------------------------------------------------------------

include '../init.php';

// 闲鱼资源网源码 www.xianyuboke.com    加载配置参数
$config = require(__DIR__ . '/config.php');

// 闲鱼资源网源码 www.xianyuboke.com    支付参数
$options = [
    'bill_date' => '20171006', // 闲鱼资源网源码 www.xianyuboke.com    对账单日期
    'bill_type' => 'ALL', // 闲鱼资源网源码 www.xianyuboke.com    账单类型
    // 闲鱼资源网源码 www.xianyuboke.com    'tar_type'  => 'GZIP', // 闲鱼资源网源码 www.xianyuboke.com    压缩账单
];

// 闲鱼资源网源码 www.xianyuboke.com    实例支付对象
$pay = new \Pay\Pay($config);

try {
    $result = $pay->driver('wechat')->gateway('bill')->apply($options);
    echo '<pre>';
    var_export($result);
} catch (Exception $e) {
    echo $e->getMessage();
}



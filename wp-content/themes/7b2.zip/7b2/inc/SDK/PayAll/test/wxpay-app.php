<?php

// 闲鱼资源网源码 www.xianyuboke.com    +----------------------------------------------------------------------
// 闲鱼资源网源码 www.xianyuboke.com    | pay-php-sdk
// 闲鱼资源网源码 www.xianyuboke.com    +----------------------------------------------------------------------
// 闲鱼资源网源码 www.xianyuboke.com    | 版权所有 2014~2017 广州楚才信息科技有限公司 [ http:// 闲鱼资源网源码 www.xianyuboke.com   www.cuci.cc ]
// 闲鱼资源网源码 www.xianyuboke.com    +----------------------------------------------------------------------
// 闲鱼资源网源码 www.xianyuboke.com    | 开源协议 ( https:// 闲鱼资源网源码 www.xianyuboke.com   mit-license.org )
// 闲鱼资源网源码 www.xianyuboke.com    +----------------------------------------------------------------------
// 闲鱼资源网源码 www.xianyuboke.com    | github开源项目：https:// 闲鱼资源网源码 www.xianyuboke.com   github.com/zoujingli/pay-php-sdk
// 闲鱼资源网源码 www.xianyuboke.com    +----------------------------------------------------------------------

include '../init.php';

// 闲鱼资源网源码 www.xianyuboke.com    加载配置参数
$config = require(__DIR__ . '/config.php');

// 闲鱼资源网源码 www.xianyuboke.com    支付参数
$options = [
    'out_trade_no'     => time(), // 闲鱼资源网源码 www.xianyuboke.com    订单号
    'total_fee'        => '101', // 闲鱼资源网源码 www.xianyuboke.com    订单金额，**单位：分**
    'body'             => '测试', // 闲鱼资源网源码 www.xianyuboke.com    订单描述
    'spbill_create_ip' => '127.0.0.1', // 闲鱼资源网源码 www.xianyuboke.com    支付人的 IP
    'notify_url'       => 'http:// 闲鱼资源网源码 www.xianyuboke.com   localhost/notify.php', // 闲鱼资源网源码 www.xianyuboke.com    定义通知URL
];

// 闲鱼资源网源码 www.xianyuboke.com    实例支付对象
$pay = new \Pay\Pay($config);

try {
    $result = $pay->driver('wechat')->gateway('app')->apply($options);
    echo '<pre>';
    var_export($result);
} catch (Exception $e) {
    echo $e->getMessage();
}



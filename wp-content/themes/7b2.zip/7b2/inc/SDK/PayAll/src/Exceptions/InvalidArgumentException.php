<?php

// 闲鱼资源网源码 www.xianyuboke.com    +----------------------------------------------------------------------
// 闲鱼资源网源码 www.xianyuboke.com    | pay-php-sdk
// 闲鱼资源网源码 www.xianyuboke.com    +----------------------------------------------------------------------
// 闲鱼资源网源码 www.xianyuboke.com    | 版权所有 2014~2017 广州楚才信息科技有限公司 [ http:// 闲鱼资源网源码 www.xianyuboke.com   www.cuci.cc ]
// 闲鱼资源网源码 www.xianyuboke.com    +----------------------------------------------------------------------
// 闲鱼资源网源码 www.xianyuboke.com    | 开源协议 ( https:// 闲鱼资源网源码 www.xianyuboke.com   mit-license.org )
// 闲鱼资源网源码 www.xianyuboke.com    +----------------------------------------------------------------------
// 闲鱼资源网源码 www.xianyuboke.com    | github开源项目：https:// 闲鱼资源网源码 www.xianyuboke.com   github.com/zoujingli/pay-php-sdk
// 闲鱼资源网源码 www.xianyuboke.com    +----------------------------------------------------------------------
// 闲鱼资源网源码 www.xianyuboke.com    | 项目设计及部分源码参考于 yansongda/pay，在此特别感谢！
// 闲鱼资源网源码 www.xianyuboke.com    +----------------------------------------------------------------------

namespace Pay\Exceptions;

/* 闲鱼资源网源码 www.xianyuboke.com*
 * 支付参数异常类
 * Class InvalidArgumentException
 * @package Pay\Exceptions
 */
class InvalidArgumentException extends \InvalidArgumentException
{
}
